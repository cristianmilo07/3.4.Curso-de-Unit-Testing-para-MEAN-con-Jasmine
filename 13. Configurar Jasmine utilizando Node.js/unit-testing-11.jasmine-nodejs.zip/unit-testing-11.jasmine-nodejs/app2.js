const saludar = nombre => `Hola ${nombre}`;
