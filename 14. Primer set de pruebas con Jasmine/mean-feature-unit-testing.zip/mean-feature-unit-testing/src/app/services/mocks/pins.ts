export const PINS = [
  {
    _id: '5c520d9c7b26f12e6d018090',
    title: 'Learning path 1',
    author: 'Cristian Marquez',
    description: 'Description',
    percentage: 0,
    url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
    tags: ['Javascript', 'Code', 'Video'],
    assets: [
      {
        _id: '5c520d9c7b26f12e6d0180a0',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: false
      },
      {
        _id: '5c520d9c7b26f12e6d0180a1',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: false
      },
      {
        _id: '5c520d9c7b26f12e6d0180a2',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: false
      }
    ]
  },
  {
    _id: '5c520d9c7b26f12e6d018091',
    title: 'Learning path 2',
    author: 'Cristian Marquez',
    description: 'Description',
    percentage: 50,
    url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
    tags: ['Javascript', 'Code', 'Video'],
    assets: [
      {
        _id: '5c520d9c7b26f12e6d0180a3',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: true
      },
      {
        _id: '5c520d9c7b26f12e6d0180a4',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: false
      },
      {
        _id: '5c520d9c7b26f12e6d0180a5',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: false
      }
    ]
  },
  {
    _id: '5c520d9c7b26f12e6d018093',
    title: 'Learning path 3',
    author: 'Cristian Marquez',
    description: 'Description',
    percentage: 100,
    url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
    tags: ['Javascript', 'Code', 'Video'],
    assets: [
      {
        _id: '5c520d9c7b26f12e6d0180a6',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: true
      },
      {
        _id: '5c520d9c7b26f12e6d0180a7',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: true
      },
      {
        _id: '5c520d9c7b26f12e6d0180a8',
        url: 'https://www.youtube.com/watch?v=mC2LRZ23AFU',
        title: 'Video Title',
        description: 'Video description',
        readed: true
      }
    ]
  }
];
