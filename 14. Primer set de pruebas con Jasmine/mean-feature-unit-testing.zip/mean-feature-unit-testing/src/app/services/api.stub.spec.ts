export class ApiStub {
  public get() {}

  public post() {}

  public put() {}

  public delete() {}
}
