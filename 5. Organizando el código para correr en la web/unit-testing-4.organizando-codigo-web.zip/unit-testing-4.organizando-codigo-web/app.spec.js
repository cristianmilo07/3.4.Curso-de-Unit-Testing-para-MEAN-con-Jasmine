console.log(saludar('Platzi'));

it('La función saluda', () => {
  expect(saludar('Platzi')).toBe('Hola Platzi');
});
