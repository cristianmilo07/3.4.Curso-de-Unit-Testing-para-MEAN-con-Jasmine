const saludar = nombre => `Hola ${nombre}`;

module.exports = saludar;
